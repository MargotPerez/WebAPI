﻿using Microsoft.EntityFrameworkCore;
//using DemoAPI;
using DemoAPI.Model;

namespace PublisherData
{
    public class PubContext : DbContext
    {
        public DbSet<BookDto> Books { get; set; }

        public DbSet<Author> Authors { get; set; }

       // public DbSet<Artist> Artists { get; set; }

       // public DbSet<Cover> Covers { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
           // optionsBuilder.UseSqlServer("Data Source = (localdb)\\MSSQLLocalDb ; Initial Catalog=PublisherDataBase;");
            optionsBuilder.UseSqlServer("Server = (localdb)\\v11.0 ; Integrated Security =true; Initial Catalog=PublisherDataBase;");
        }

    }
    }
