﻿using DemoAPI.Model;
using static System.Reflection.Metadata.BlobBuilder;

namespace DemoAPI.Data
{
    public class AuthorsData
    {
        public List<AuthorDto> Authors { get; set; }

        public static AuthorsData current = new AuthorsData();
        public AuthorsData()
        {
            Authors = new List<AuthorDto>() {

            new AuthorDto()
                {
                Id = 1,
                FirstName = "Charles",
                LastName = "Darwin",
                Books = new List<BookDto>()
                    {
                    new BookDto() {
                    Id =1,
                    Title = "The Descent of a man",
                    PublishDate = new DateOnly(1871,1,1),
                    Price = 18.75m},

                    new BookDto()
                    {Id = 2,
                    Title = "L'origine des espèces",
                    PublishDate = new DateOnly(1859,1,1),
                    Price = 22.75m}
                }
            },
            new AuthorDto()
            {
                Id = 2,
                FirstName = "Ivan",
                LastName = "Pavlov",
                Books = new List<BookDto>()
                {
                    new BookDto() {
                    Id = 3,
                    Title = "Conditioned reflexes",
                    PublishDate = new DateOnly(1927, 1, 1),
                    Price = 25.50m
                    }
                }
            }
        };
        }
    }
}



                




            //new BookDto() { Id = 1, Title = "The Descent of a Man", Author = "Charles Darwin", PublishDate = new DateOnly(1871,1,1), Price = 18.75m },

            //new BookDto() { Id = 2, Title = "Conditioned Reflexes", Author = "Ivan Pavlov", PublishDate = new DateOnly(1927,1,1), Price = 45.82m },

            //new BookDto() { Id = 3, Title = "Eugénie Grandet", Author = "Honoré de Balzac", PublishDate = new DateOnly(1875,1,1), Price = 10.50m }

       // };

    //    }
    //}
