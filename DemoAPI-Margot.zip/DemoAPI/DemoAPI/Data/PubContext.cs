﻿using DemoAPI.Entities;
using Microsoft.EntityFrameworkCore;


namespace PublisherData
{
    public class PubContext : DbContext
    {
        public DbSet<Book> Books { get; set; }

        public DbSet<Author> Authors { get; set; }

       // public DbSet<Artist> Artists { get; set; }

       // public DbSet<Cover> Covers { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // mieux de def la chaine ailleurs (pas dans le context)
            optionsBuilder.UseSqlServer("Data Source = (localdb)\\MSSQLLocalDb ; Initial Catalog=PublisherDataBase;");
            //optionsBuilder.UseSqlServer("Server = (localdb)\\v11.0 ; Integrated Security =true; Initial Catalog=PublisherDataBase;");
        }

        //Donner des données de démarrage (seed data)
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Author>().HasData(
                new Author { Id = 2, FirstName = "Jeff", LastName = "Olsen" });

            // Renommer colonnes
            // modelBuilder.Entity<Book>().Property(b => b.Title).HasColumnName("Main Title");

            var authors = new Author[]
            {
                new Author { Id =3,FirstName = "Jeff", LastName="Olsssen"},
                new Author { Id =4,FirstName = "Victor", LastName="Hugo"},
                new Author { Id =5,FirstName = "Emile", LastName="Zola"}
            };
            modelBuilder.Entity<Author>().HasData(authors);

            var books = new Book[]
            {
                new Book{BookId = 1, AuthorId = 2, Title="The slight Edge", PublishDate= new DateOnly(1990,1,1), BasePrice=17.50m},
                new Book{BookId = 2, AuthorId = 2, Title="deuxieme livre", PublishDate= new DateOnly(1952,1,1), BasePrice=21.50m},
                new Book{BookId = 3, AuthorId = 3, Title="Blabla", PublishDate= new DateOnly(1990,1,1), BasePrice=17.50m}
            };
            modelBuilder.Entity<Book>().HasData(books);
        }


    }
}
