﻿using DemoAPI.Data;
using DemoAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PublisherData;
using Microsoft.EntityFrameworkCore;
using System;
using DemoAPI.Entities;
using DemoAPI.Service;

namespace DemoAPI.Controllers
{
    [Route("api/authors/{AuthorId}/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {

        private PubContext _context;
        //private readonly MyService _myservice;
        //public BooksController(PubContext context,MyService myservice)
        public BooksController(PubContext context)
        {
            _context = context;
        }

        [HttpGet]
        //public JsonResult GetBooks()
        public ActionResult<IEnumerable<BookDto>> GetBooksByAuthor(int AuthorId)
        {
          //  _myservice.showRequestDetails("GET", DateTime.Now);
            var author = _context.Authors.Include(a=>a.Books).FirstOrDefault(a => a.Id == AuthorId);
            if (author == null)
            {
                return NotFound();
            }
            var books = new List<BookDto>();
            foreach (var b in author.Books) 
            {
                var book = new BookDto() { Id = b.BookId, Title = b.Title, Price = b.BasePrice, PublishDate = b.PublishDate };
                books.Add(book);
            }

            return Ok(books);
        }


        //[HttpGet]
        ////public JsonResult GetBooks()
        //public ActionResult<IEnumerable<BookDto>> GetBooks(int AuthorId)
        //{
        //   var author = AuthorsData.current.Authors.FirstOrDefault(a=>a.Id == AuthorId);
        //    if (author == null)
        //    {
        //        return NotFound();
        //    }
        //    return Ok(author.Books);
        //}

        [HttpGet("{id}")]
        //public JsonResult GetBookById(int id)
        public ActionResult<BookDto> GetBookById(int AuthorId,int id)
        {
           // _myservice.showRequestDetails("GET", DateTime.Now);
            var author = _context.Authors.Include(a=>a.Books).FirstOrDefault(a => a.Id == AuthorId);

            if (author == null)
            {
                return NotFound();
            }

            var book = author.Books.FirstOrDefault(b=>b.BookId == id);
            if (book == null)
            {
                return NotFound();
            }


            return Ok(new BookDto { Id = book.AuthorId, Title = book.Title, Price = book.BasePrice, PublishDate = book.PublishDate });
        }

        


    [HttpPost]

        public ActionResult<BookDto> AddBook(int AuthorId,BookDto book)
        {
           // _myservice.showRequestDetails("POST", DateTime.Now);
            var author = _context.Authors.FirstOrDefault(a => a.Id == AuthorId);

            if (author == null)
            {
                return NotFound();
            }

            var newBook = new Book() { Title = book.Title, BasePrice = book.Price, PublishDate = book.PublishDate, AuthorId = AuthorId };

            author.Books.Add(newBook);
            _context.SaveChanges();

           // return new JsonResult(book);// svt on retourne que l'ID (car c'est info que le client n'a pas encore)
            return Ok(book);
        }

        

        [HttpPut("{id}")]

        public ActionResult<BookDto> EditBook(int AuthorId, int id, BookDto book)
        {
            //_myservice.showRequestDetails("PUT", DateTime.Now);
            var author = _context.Authors.Include(a=>a.Books).FirstOrDefault(a => a.Id == AuthorId);

            if (author == null)// FindIndex renvoie -1 si trouve pas, ne renvoie pas null
            { return NotFound(); }
               

                var index = author.Books.FindIndex(b => b.BookId == id);
                if (index == -1) 
                {  return NotFound(); }

            author.Books[index] = new Book() { Title = book.Title, BasePrice = book.Price, PublishDate = book.PublishDate };
            return Ok(book);    
        }

        [HttpDelete("{id}")]

        public ActionResult<string> DeleteBook(int AuthorId, int id)
        {
           // _myservice.showRequestDetails("DELETE", DateTime.Now);
            var author = _context.Authors.Include(a=>a.Books).FirstOrDefault(a => a.Id == AuthorId);
            
            if (author == null) 
            
            { return NotFound(); }

            var index = author.Books.FindIndex(b => b.BookId == id);
            if (index == -1)
            { return NotFound(); }

            author.Books.RemoveAt(index);
            _context.SaveChanges();
            
            return Ok("The book has been succesfully deleted");
        }
         
            
        }

    }

