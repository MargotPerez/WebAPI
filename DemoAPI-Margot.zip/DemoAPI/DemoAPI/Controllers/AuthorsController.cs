﻿using DemoAPI.Data;
using DemoAPI.Entities;
using DemoAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PublisherData;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using DemoAPI.Service;

namespace DemoAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthorsController : ControllerBase
    {
        private PubContext _context;
        //private readonly MyService _myservice;
        //public AuthorsController(PubContext context, MyService myservice)
        public AuthorsController(PubContext context)
        {
            _context = context;
        }

        //[HttpGet]
        ////public JsonResult GetBooks()
        //public ActionResult<IEnumerable<AuthorDto>> GetAuthors()
        //{
          
        //    return Ok(AuthorsData.current.Authors);
        //}

        [HttpGet]
        public ActionResult<IEnumerable<AuthorDto>> GetAuthors()
        {
            //_myservice.showRequestDetails("GET", DateTime.Now);

            var authors = _context.Authors.Include(a=>a.Books);
            var authorsToReturn = new List<AuthorDto>();

            foreach (var author in authors)
            {
                var auth = new AuthorDto { Id = author.Id, FirstName = author.FirstName, LastName = author.LastName };

                foreach (var book in author.Books)
                {
                    auth.Books.Add(new BookDto() { Id = book.AuthorId, Title = book.Title, Price = book.BasePrice, PublishDate = book.PublishDate });
                }
                authorsToReturn.Add(auth);
            }

            return Ok(authorsToReturn);
        }


        [HttpGet("{id}")]
        //public JsonResult GetBookById(int id)
        public ActionResult<AuthorDto> GetAuthorById(int id)
        {
           // _myservice.showRequestDetails("GET", DateTime.Now);

            var author = _context.Authors.Include(a=>a.Books).FirstOrDefault(a => a.Id == id);
            //var author = _context.Authors.Find(id); // plus optimal d'utiliser Find que FirstOrDefault
            if (author == null)
            {
                return NotFound();
            }

            var authorsToReturn = new AuthorDto() { Id = author.Id, FirstName = author.FirstName, LastName = author.LastName };
            foreach (var book in author.Books)
            {
                authorsToReturn.Books.Add(new BookDto() { Id = book.BookId, Title = book.Title, Price = book.BasePrice, PublishDate = book.PublishDate });
            }
            return Ok(authorsToReturn);
        }

        [HttpPost]

        public ActionResult<AuthorDto> AddAuthor(AuthorDto author)
        {
            //_myservice.showRequestDetails("POST", DateTime.Now);

            var authorToAdd = new Author() {FirstName = author.FirstName, LastName = author.LastName };
           foreach(var book in author.Books)
            {
                authorToAdd.Books.Add(new Book() { Title = book.Title, BasePrice = book.Price, PublishDate = book.PublishDate });
            }

            _context.Authors.Add(authorToAdd);
            _context.SaveChanges();
            // return new JsonResult(book);// svt on retourne que l'ID (car c'est info que le client n'a pas encore)
            return Ok(author);

            
        }





                [HttpPut("{id}")]

              public ActionResult<AuthorDto> EditAuthor(int id, AuthorDto author)
               {
           // _myservice.showRequestDetails("PUT", DateTime.Now);
            //var bookToEdit = BooksData.current.Books.FirstOrDefault(b => b.Id == id);

            //var index = AuthorsData.current.Authors.FindIndex(b => b.Id == id);

            var authorToEdit = _context.Authors.Include(a=> a.Books).FirstOrDefault(a => a.Id == id);

                   //var index = _context.Authors.FindIndex(b => b.Id == id);

                   if (authorToEdit == null)
                   {
                       return NotFound();
                   }

                    authorToEdit.FirstName = author.FirstName;
                    authorToEdit.LastName = author.LastName;

            _context.SaveChanges();

            return Ok(author);

                   //if (index != -1)// FindIndex renvoie -1 si trouve pas, ne renvoie pas null
                   //{
                       //BooksData.current.Books.Remove(bookToEdit);
                       //BooksData.current.Books.Add(book);

                   //    _context.Authors[index] = author;
                   //    return Ok(author);
                   //}
                   //else { return NotFound(); }


               }
       
        [HttpDelete("{id}")]

        public ActionResult<string> DeleteAuthor(int id)
        {
           // _myservice.showRequestDetails("DELETE", DateTime.Now);
            //var bookToDelete = BooksData.current.Books.FirstOrDefault(b => b.Id == id);

            //var authorToDelete = _context.Authors.FirstOrDefault(a => a.Id == id);
            var authorToDelete = _context.Authors.Find(id);

            //var index = _context.Authors.FindIndex(b => b.Id == id);

            //if (bookToDelete != null)
            if (authorToDelete != null)
            //if (index != -1)
            {
                
                _context.Authors.Remove(authorToDelete);
                _context.SaveChanges();
                return Ok("The book has been succesfully deleted");
            }
            else { return NotFound(); }

        }

    }
}
