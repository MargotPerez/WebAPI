﻿namespace DemoAPI.Service
{
    public class MyService
    {
        public void showRequestDetails(string requestType, DateTime requestDate)
        {
            Console.WriteLine($"Une néo requete de type {requestType} a été détectée à : {requestDate}");
        }
    }
}
