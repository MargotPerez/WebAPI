﻿using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace DemoAPI.Entities
{
    public class Book
    {
        public int BookId { get; set; }

        public string Title { get; set; }
        public DateOnly PublishDate { get; set; }
        public decimal BasePrice { get; set; } = new decimal(0);
        public Author Author { get; set; }

        public int AuthorId { get; set; }

        //public Cover Cover { get; set; }
    }
}
