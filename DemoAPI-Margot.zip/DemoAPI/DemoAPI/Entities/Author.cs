﻿using PublisherData;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace DemoAPI.Entities
{
    public class Author
    {
        public int Id { get; set; }
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public List<Book> Books { get; set; } = new List<Book>();

        //public override string ToString()
       // {
         //   return $"Auteur {this.FirstName} {this.LastName}";
       // }
    }

}
